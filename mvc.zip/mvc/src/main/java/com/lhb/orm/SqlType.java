package com.lhb.orm;

public enum SqlType {
	SELECT,DELETE,UPDATE,INSERT
}
